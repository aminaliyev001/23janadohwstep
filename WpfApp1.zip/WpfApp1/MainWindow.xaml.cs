﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.Common;
using System.Data.SqlClient;
using System.Reflection.PortableExecutable;
using System.Collections.ObjectModel;
using System.ComponentModel.Design;
using Microsoft.VisualBasic;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public string str = "Data Source=AMIN_360\\SQLEXPRESS;Initial Catalog=Library;Integrated Security=True";

        public ObservableCollection<Category> category_list { get; set; }
        public ObservableCollection<Book> books_list { get; set; }
        public MainWindow()
        {
            InitializeComponent();
            category_list = new ObservableCollection<Category>();
            books_list = new ObservableCollection<Book>();
            op();
            this.DataContext = this;
        }
        public class Category
        {
            public int Id { get; set; }
            public string Name { get; set; }
        }
        public class Book
        {
            public int Id { get; set; }
            public string Name { get; set; }
        }

        public void op()
        {
            SqlConnection conn = new SqlConnection(str);
            try
            {
                conn.Open();
                string query1 = "SELECT * FROM Categories";
                SqlCommand command = new SqlCommand(query1, conn);
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    category_list.Add(new Category
                    {
                        Id = reader.GetInt32(0),
                        Name = reader.GetString(1)
                    });
                }
                reader.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                MessageBox.Show(e.Message);
            }
            finally
            {
                conn.Close();
            }
        }
        public void op_b(int id)
        {
            SqlConnection conn = new SqlConnection(str);
            try
            {
                conn.Open();
                string query1 = "SELECT * FROM Books WHERE Id_Category = @idc";
                SqlCommand command = new SqlCommand(query1, conn);
                command.Parameters.AddWithValue("@idc", id);
                SqlDataReader reader = command.ExecuteReader();
                books_list.Clear();
                while (reader.Read())
                {
                    books_list.Add(new Book
                    {
                        Id = reader.GetInt32(0),
                        Name = reader.GetString(1)
                    });
                }
                reader.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                MessageBox.Show(e.Message);
            }
            finally
            {
                conn.Close();
            }
        }
        public void op3(string query)
        {
            SqlConnection sqlConnection = new SqlConnection(str);
            try
            {
                sqlConnection.Open();
                string selectQuery = query;
                SqlCommand sqlCommand = new SqlCommand(selectQuery, sqlConnection);
                SqlDataReader reader = sqlCommand.ExecuteReader();
                string result = "";
                do
                {
                    bool line = false;
                    while (reader.Read())
                    {
                        if (!line)
                        {
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                result+=($"{reader.GetName(i)}   ");
                            }
                            result += "\n";
                            line = !line;
                        }
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            result += ($"{reader[i]}   ");
                        }
                        result += "\n";
                    }
                    result += "\n";
                    result += "\n";
                    result += "\n";
                }
                while (reader.NextResult());
                MessageBox.Show(result);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                sqlConnection.Close();
            }
        }
        private void categorycomboboxchange(object sender, SelectionChangedEventArgs e)
        {
            if (combobox_category.SelectedItem is Category selectedCategory)
            {
                int id = selectedCategory.Id;
                op_b(id);
            }
        }
        public void Button_Click(object sender, EventArgs e)
        {
            string text = textbox.Text; 
            op3(text);
        }
    }
}